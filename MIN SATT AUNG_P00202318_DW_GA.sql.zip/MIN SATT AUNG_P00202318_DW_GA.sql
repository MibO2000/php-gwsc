-- MySQL dump 10.13  Distrib 8.0.33, for macos13.3 (arm64)
--
-- Host: localhost    Database: ASSIGNMENT
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gwsc_admin`
--

DROP TABLE IF EXISTS `gwsc_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_admin` (
  `admin_id` varchar(20) NOT NULL,
  `admin_address` varchar(255) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `admin_password` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `admin_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `a_id_email` (`admin_id`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_admin`
--

LOCK TABLES `gwsc_admin` WRITE;
/*!40000 ALTER TABLE `gwsc_admin` DISABLE KEYS */;
INSERT INTO `gwsc_admin` VALUES ('ADMIN0001','485, Aung Yandanar 3rd St, 28 Ward','min@email.com','$2y$10$vmvWe0f./RsUAFU6QIBEI.dQFXgXubYpwvT1MJ3uqPPmLhSbrAz1u','09763940667','Min');
/*!40000 ALTER TABLE `gwsc_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gwsc_booking`
--

DROP TABLE IF EXISTS `gwsc_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_booking` (
  `booking_id` varchar(30) NOT NULL,
  `customer_id` varchar(30) DEFAULT NULL,
  `order_time` timestamp(6) NULL DEFAULT NULL,
  `booking_status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`booking_id`),
  UNIQUE KEY `b_id` (`booking_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `gwsc_booking_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `gwsc_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_booking`
--

LOCK TABLES `gwsc_booking` WRITE;
/*!40000 ALTER TABLE `gwsc_booking` DISABLE KEYS */;
INSERT INTO `gwsc_booking` VALUES ('BOOK0001','CUS0001','2023-07-20 18:06:53.000000','SUCCESS'),('BOOK0002','CUS0001','2023-07-20 18:06:53.000000','SUCCESS'),('BOOK0003','CUS0001','2023-07-25 06:28:50.877795','INIT');
/*!40000 ALTER TABLE `gwsc_booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gwsc_booking_detail`
--

DROP TABLE IF EXISTS `gwsc_booking_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_booking_detail` (
  `booking_detail_id` varchar(30) NOT NULL,
  `booking_id` varchar(30) NOT NULL,
  `package_id` varchar(30) NOT NULL,
  `quantity` int DEFAULT NULL,
  `tax` int DEFAULT NULL,
  `price` int DEFAULT NULL,
  `total_price` int DEFAULT NULL,
  `booking_date` datetime DEFAULT NULL,
  PRIMARY KEY (`booking_detail_id`),
  UNIQUE KEY `bd_id` (`booking_detail_id`),
  KEY `booking_id` (`booking_id`),
  CONSTRAINT `gwsc_booking_detail_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `gwsc_booking` (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_booking_detail`
--

LOCK TABLES `gwsc_booking_detail` WRITE;
/*!40000 ALTER TABLE `gwsc_booking_detail` DISABLE KEYS */;
INSERT INTO `gwsc_booking_detail` VALUES ('BOOKDE0001','BOOK0001','PACK0001',1,5,50,55,'2023-07-27 00:00:00'),('BOOKDE0002','BOOK0002','PACK0001',1,5,50,55,'2023-07-19 00:00:00'),('BOOKDE0003','BOOK0002','PACK0001',1,5,50,55,'2023-07-22 00:00:00'),('BOOKDE0004','BOOK0002','PACK0003',1,20,200,220,'2023-07-28 00:00:00'),('BOOKDE0005','BOOK0003','PACK0001',1,5,50,55,'2023-07-26 00:00:00');
/*!40000 ALTER TABLE `gwsc_booking_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gwsc_customer`
--

DROP TABLE IF EXISTS `gwsc_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_customer` (
  `customer_id` varchar(20) NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `surname` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `customer_password` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `customer_address` varchar(50) DEFAULT NULL,
  `view_count` int DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `c_id_email` (`customer_id`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_customer`
--

LOCK TABLES `gwsc_customer` WRITE;
/*!40000 ALTER TABLE `gwsc_customer` DISABLE KEYS */;
INSERT INTO `gwsc_customer` VALUES ('CUS0001','Min','Aung','min@email.com','$2y$10$7EHf.2VKoXQLqiYu5fL3NuqT47I9M/3kOcMRWpPRj/wQHYeKHu0jS','09763940667','485, Aung Yandanar 3rd St, 28 Ward',133),('CUS0002','Satt','Min','satt@mail.com','$2y$10$WGIMkevk/pigHKFJyAuX2OIPo20qdo81WknqEZ5fSa5A65nZeQWjO','09681487689','Yangon',3);
/*!40000 ALTER TABLE `gwsc_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gwsc_location`
--

DROP TABLE IF EXISTS `gwsc_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_location` (
  `location_id` varchar(30) NOT NULL,
  `location_type_id` varchar(30) DEFAULT NULL,
  `location_name` varchar(20) DEFAULT NULL,
  `full_location` varchar(255) DEFAULT NULL,
  `location_picture` varchar(255) DEFAULT NULL,
  `location_description` longtext,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `lt_id_name` (`location_id`,`location_name`),
  KEY `location_type_id` (`location_type_id`),
  CONSTRAINT `gwsc_location_ibfk_1` FOREIGN KEY (`location_type_id`) REFERENCES `gwsc_location_type` (`location_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_location`
--

LOCK TABLES `gwsc_location` WRITE;
/*!40000 ALTER TABLE `gwsc_location` DISABLE KEYS */;
INSERT INTO `gwsc_location` VALUES ('LOCAL0001','LOCTYP0001','Banff National Park','Banff National Park, Alberta, Canada','64c54b3fc200f-canada.jpeg','Embark on a memorable Rocky Mountain Wilderness Retreat at Banff National Park. Set up camp amidst the majestic peaks and pristine forests of the Canadian Rockies. Our Family Tent pitches offer ample space for family bonding and stargazing. During the day, explore the park\'s scenic trails, encountering abundant wildlife and breathtaking vistas. At night, gather around the campfire, sharing tales under a star-studded sky. The Rocky Mountain Wilderness Retreat celebrates the serenity and wonder of camping in one of the world\'s most iconic national parks.'),('LOCAL0002','LOCTYP0003','Serengeti Park','Serengeti National Park, Tanzania','64c54bcc812f0-serrenti.jpeg','Our One-Man Tent pitches offer an intimate escape for solo adventurers seeking a unique safari experience. Witness the Great Migration of wildebeest and zebras, and encounter majestic lions and elephants on game drives. As the sun sets over the Serengeti, enjoy the magic of the African night sky from your campsite. The Safari Under the Stars promises an extraordinary camping journey immersed in the raw beauty of the African wilderness.'),('LOCAL0003','LOCTYP0002','Phi Phi Islands',' Phi Phi Islands, Thailand','64c54be70b0ac-phi phi.jpeg','Immerse yourself in the Tropical Aqua Bliss of Phi Phi Islands, Thailand\'s aquatic paradise. Discover pristine beaches, limestone cliffs, and emerald waters on these exotic islands. Our Two-Person Tent pitches offer beachside accommodations, allowing you to wake up to the soothing sounds of the ocean. Spend your days snorkeling in the vibrant coral reefs, encountering colorful marine life. Wade into the azure waters of Maya Bay, known for its breathtaking beauty. The Tropical Aqua Bliss invites you to unwind in Thailand\'s idyllic haven of wild swimming and coastal wonders.'),('LOCAL0004','LOCTYP0004','Plitvice Lakes','Plitvice Lakes National Park, Croatia','64c54c040c64b-croatia.jpeg','Embark on an Enchanted Lakeside Oasis at Plitvice Lakes National Park, a hidden gem in Croatia\'s natural wonders. Camp amidst lush forests and turquoise lakes in our One-Man Tent pitches. Explore the park\'s cascading waterfalls and emerald lakes, connected by wooden walkways. Dive into the crystalline waters for a unique wild swimming experience, surrounded by serene landscapes. Plitvice Lakes\' surreal beauty promises moments of tranquility and awe-inspiring encounters with nature\'s artistry. The Enchanted Lakeside Oasis is an invitation to reconnect with the purity and magic of wild swimming amidst Croatia\'s breathtaking national park.');
/*!40000 ALTER TABLE `gwsc_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gwsc_location_type`
--

DROP TABLE IF EXISTS `gwsc_location_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_location_type` (
  `location_type_id` varchar(30) NOT NULL,
  `location_type_name` varchar(20) DEFAULT NULL,
  `location_description` longtext,
  PRIMARY KEY (`location_type_id`),
  UNIQUE KEY `l_id_name` (`location_type_id`,`location_type_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_location_type`
--

LOCK TABLES `gwsc_location_type` WRITE;
/*!40000 ALTER TABLE `gwsc_location_type` DISABLE KEYS */;
INSERT INTO `gwsc_location_type` VALUES ('LOCTYP0001','Hilly (Mountain)','The Hilly or Mountain locations offer a camping experience surrounded by the majestic peaks and lush forests of mountains. Campers can immerse themselves in the tranquility of nature, waking up to awe-inspiring vistas and breathing in the crisp mountain air. These locations provide an excellent opportunity for hiking adventures, exploring scenic trails, and encountering diverse wildlife. Camping amidst hilly terrain offers a sense of seclusion and a chance to connect with the natural world on a deeper level. Whether it\'s gazing at starlit skies from your tent or gathering around a campfire, Hilly locations create a serene and unforgettable camping experience.'),('LOCTYP0002','Beach (Island)','Beach locations on islands are a paradise for camping enthusiasts seeking coastal beauty and relaxation. Set up camp along pristine shores, where the gentle lapping of waves becomes a lullaby. Wake up to breathtaking sunrises and enjoy leisurely walks along sandy beaches. Beach camping offers an array of activities, from snorkeling in vibrant coral reefs to building sandcastles with loved ones. The rhythmic sound of the ocean provides a soothing backdrop to evenings spent stargazing. Camping on islands brings a sense of seclusion and serenity, making it an ideal escape for those seeking solace amidst coastal wonders.'),('LOCTYP0003','Savannah (Grassland)','Savannah locations offer a unique camping experience amid expansive grasslands and diverse ecosystems. Campers can immerse themselves in the vastness of the savannah, encountering iconic wildlife and witnessing breathtaking sunsets over the horizon. Camping in savannahs allows for extraordinary wildlife encounters, from witnessing the Great Migration to observing majestic predators in their natural habitat. Enjoy campfire stories under the starlit sky, surrounded by the sights and sounds of the grasslands. Savannah camping provides a sense of connection with the natural rhythms of the wild, offering an unforgettable adventure for nature enthusiasts.'),('LOCTYP0004','Lake (National Park)','Camping by a tranquil lake within a National Park is an invitation to embrace the beauty of still waters and pristine landscapes. Wake up to the serene reflections of surrounding forests mirrored on the lake\'s surface. Lake camping offers opportunities for leisurely boating, fishing, and lakeside picnics. National Parks often provide guided nature walks, allowing campers to explore the unique flora and fauna of the area. Evenings by the lake are magical, as campers witness the colors of sunset dancing on the water. Camping within a National Park and near a serene lake is an immersive experience that fosters a deep appreciation for nature\'s wonders.');
/*!40000 ALTER TABLE `gwsc_location_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gwsc_package`
--

DROP TABLE IF EXISTS `gwsc_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_package` (
  `package_id` varchar(30) NOT NULL,
  `package_name` varchar(20) DEFAULT NULL,
  `package_type_id` varchar(30) DEFAULT NULL,
  `pitch_id` varchar(30) DEFAULT NULL,
  `location_id` varchar(30) DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `price` int DEFAULT NULL,
  `pitch_description` longtext,
  `package_image` varchar(255) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `latitude` decimal(8,4) DEFAULT NULL,
  `longitude` decimal(8,4) DEFAULT NULL,
  PRIMARY KEY (`package_id`),
  UNIQUE KEY `p_id_name` (`package_id`,`package_name`),
  KEY `pitch_id` (`pitch_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `gwsc_package_ibfk_1` FOREIGN KEY (`pitch_id`) REFERENCES `gwsc_pitch` (`pitch_id`),
  CONSTRAINT `gwsc_package_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `gwsc_location` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_package`
--

LOCK TABLES `gwsc_package` WRITE;
/*!40000 ALTER TABLE `gwsc_package` DISABLE KEYS */;
INSERT INTO `gwsc_package` VALUES ('PACK0001','Alpine Escapade','PACTYP0002','PITCH0002','LOCAL0001',24,200,'Embark on an Alpine Escapade in the heart of Banff National Park, where the majestic mountains embrace you in their natural splendor. Our Family Tent pitches offer a cozy haven amidst the wilderness, inviting you to relax and bond with loved ones. During the day, explore a network of trails that lead to breathtaking viewpoints and hidden alpine lakes. As the sun sets, gather around the campfire, sharing stories under a starlit sky. The Alpine Escapade promises a harmonious blend of nature\'s grandeur and cherished moments around the campfire.','64c54d7174fa8-canada 2.jpeg',5,51.4968,-115.9281),('PACK0002','Safari Under Stars','PACTYP0002','PITCH0001','LOCAL0002',48,250,'Embark on a Serengeti Safari Sojourn, where the vast savannah teems with wildlife, and each day unfolds in a mesmerizing tapestry of nature\'s wonders. Our One-Man Tent pitches offer an intimate retreat to savor the sounds of the wild. Experience thrilling game drives, witnessing the untamed beauty of the African plains. As the golden sun dips below the horizon, bask in the warmth of a campfire, mesmerized by the distant roars of lions. The Serengeti Safari Sojourn is an unforgettable adventure immersed in the untamed spirit of the African wilderness.','64c54dba0a95c-desert.jpeg',5,-2.3333,34.8333),('PACK0003','Tropical Aqua Bliss','PACTYP0001','PITCH0003','LOCAL0003',48,300,'Embark on an Azure Coast Odyssey to the Phi Phi Islands, where turquoise waters, pristine beaches, and limestone cliffs create a tropical paradise. Our Two-Person Tent pitches offer a cozy beachside retreat, a stone\'s throw away from the shimmering sea. Spend your days snorkeling in vibrant coral gardens, swimming with playful marine life, and relaxing on secluded shores. As twilight descends, marvel at the vibrant hues of the sunset painting the sky. The Azure Coast Odyssey beckons you to embrace the tranquility and allure of Thailand\'s island gems.','64c54df05c985-thai.jpeg',5,7.7407,98.7784),('PACK0004','Enchanted Lakeside','PACTYP0003','PITCH0002','LOCAL0004',24,400,'Immerse yourself in Crystal Lakes Serenity at Plitvice Lakes National Park, where a dreamlike landscape of cascading waterfalls and emerald lakes unfolds before you. Our One-Man Tent pitches offer a serene retreat amid lush forests and pristine waters. Discover the beauty of the park on scenic trails and boardwalks, leading you to mesmerizing viewpoints. Wade into the crystal-clear lakes, where wild swimming becomes an ethereal experience. The Crystal Lakes Serenity invites you to revel in the harmony of nature\'s artistry and the peacefulness of Croatia\'s national treasure.','64c54e3a83ee3-cratia 2.jpeg',4,44.8654,15.5820);
/*!40000 ALTER TABLE `gwsc_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gwsc_package_type`
--

DROP TABLE IF EXISTS `gwsc_package_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_package_type` (
  `package_type_id` varchar(30) NOT NULL,
  `package_type_name` varchar(20) DEFAULT NULL,
  `package_description` longtext,
  `picture` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`package_type_id`),
  UNIQUE KEY `pt_id_name` (`package_type_id`,`package_type_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_package_type`
--

LOCK TABLES `gwsc_package_type` WRITE;
/*!40000 ALTER TABLE `gwsc_package_type` DISABLE KEYS */;
INSERT INTO `gwsc_package_type` VALUES ('PACTYP0001','Swimming','Dive Into a World of Refreshment, Health, and Joy','64b941355515d-wild swim.jpeg'),('PACTYP0002','Camping','Embrace the Great Outdoors and Discover the Essence of Adventure','64b941dba4c35-wildcamping.jpg'),('PACTYP0003','Camping & Swimming','An Immersive Adventure in Nature\'s Playground','64b943aa3f121-wsc.jpeg');
/*!40000 ALTER TABLE `gwsc_package_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gwsc_pitch`
--

DROP TABLE IF EXISTS `gwsc_pitch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_pitch` (
  `pitch_id` varchar(30) NOT NULL,
  `pitch_name` varchar(20) DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `price` int DEFAULT NULL,
  `pitch_description` longtext,
  `pitch_image` varchar(255) DEFAULT NULL,
  `pitch_type_id` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`pitch_id`),
  UNIQUE KEY `p_id_name` (`pitch_id`,`pitch_name`),
  KEY `pitch_type_id` (`pitch_type_id`),
  CONSTRAINT `gwsc_pitch_ibfk_1` FOREIGN KEY (`pitch_type_id`) REFERENCES `gwsc_pitch_type` (`pitch_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_pitch`
--

LOCK TABLES `gwsc_pitch` WRITE;
/*!40000 ALTER TABLE `gwsc_pitch` DISABLE KEYS */;
INSERT INTO `gwsc_pitch` VALUES ('PITCH0001','Recreational vehicle',24,200,'Experience the essence of simplicity and freedom with our RC (Recreational Vehicle) pitch. Designed to accommodate motorhomes and caravans, our spacious RC pitches offer a convenient and comfortable stay amidst the wilderness. Park your vehicle amidst picturesque landscapes and enjoy the convenience of on-site facilities, including access to water and electricity hook-ups. Embrace the flexibility of RV camping, where you can explore multiple destinations while having a cozy home on wheels. Whether you\'re a seasoned traveler or embarking on your first RV adventure, our RC pitches provide a haven for relaxation after days of exploration. Immerse yourself in the natural beauty surrounding you, and savor the enchanting sunsets from the comfort of your own motorhome or caravan. At GWSC, we cater to RV enthusiasts seeking an enriching outdoor experience, combining the joy of travel with the tranquility of nature.','64b93ba6021ba-rv.jpeg','PITYP0003'),('PITCH0002','One Man Tent',24,60,'For solo adventurers seeking solace and self-discovery, our one-man tent pitches provide a cozy and immersive camping experience. Nestle your compact tent amidst nature\'s embrace, offering privacy and tranquility. Wake up to the gentle sounds of rustling leaves and birdsong, as you greet the day surrounded by breathtaking landscapes. Our one-man tent pitches offer an intimate connection with nature, allowing you to fully embrace the wild and contemplate the beauty of the world around you. Whether you\'re an experienced solo camper or venturing into the wild on your own for the first time, our pitches are designed to provide a safe and secure haven for your solo escapades. At GWSC, we celebrate the spirit of individual exploration and offer a warm welcome to all adventurers seeking a profound connection with nature.','64b93fb87687a-one man tent.jpeg','PITYP0001'),('PITCH0003','Double Tent',24,100,'Experience the joys of shared adventures with our two-person tent pitches. Nestled in nature\'s embrace, our spacious pitches offer a perfect setting for bonding with friends or loved ones amidst the great outdoors. Unwind in the comfort of a cozy tent, where you can immerse yourself in the tranquility of nature while sharing cherished moments with your camping companion. Explore nearby trails, enjoy stargazing sessions, or simply relish the simple pleasures of campfire conversations. Our two-person tent pitches offer a balance of camaraderie and privacy, providing a seamless blend of shared experiences and personal space. Whether you\'re embarking on a romantic getaway or forming lasting memories with a close friend, our pitches cater to your need for a memorable and enjoyable camping experience. At GWSC, we believe that sharing adventures with loved ones deepens our connection with nature and each other, creating memories that last a lifetime.','64b9404f1535b-two person tent.jpg','PITYP0002'),('PITCH0004','Family Tent',24,200,'Foster togetherness and create cherished memories with our family tent pitches. Designed to accommodate larger groups, our spacious pitches provide a delightful camping experience for families seeking quality time amidst nature. Set up camp in the heart of the wilderness, where you can bond over campfire stories, cook delicious meals together, and marvel at the wonders of nature as a united family. Our family tent pitches offer ample space for children to play freely, fostering an atmosphere of joy and exploration. Share the excitement of wild swimming adventures, guided nature walks, and scenic picnics, creating a sense of wonder and unity within your family. Embrace the tranquility of the great outdoors as you relax and connect with your loved ones, away from the distractions of everyday life. At GWSC, we celebrate the power of family bonds and offer pitches that nurture the spirit of adventure and togetherness, providing an extraordinary camping experience for every member of the family.','64b940ca6f430-family.jpeg','PITYP0003');
/*!40000 ALTER TABLE `gwsc_pitch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gwsc_pitch_type`
--

DROP TABLE IF EXISTS `gwsc_pitch_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_pitch_type` (
  `pitch_type_id` varchar(30) NOT NULL,
  `pitch_type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`pitch_type_id`),
  UNIQUE KEY `pt_id_type` (`pitch_type_id`,`pitch_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_pitch_type`
--

LOCK TABLES `gwsc_pitch_type` WRITE;
/*!40000 ALTER TABLE `gwsc_pitch_type` DISABLE KEYS */;
INSERT INTO `gwsc_pitch_type` VALUES ('PITYP0001','One Person'),('PITYP0002','Two Person'),('PITYP0003','Family Type');
/*!40000 ALTER TABLE `gwsc_pitch_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gwsc_review`
--

DROP TABLE IF EXISTS `gwsc_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gwsc_review` (
  `review_id` varchar(30) NOT NULL,
  `customer_id` varchar(30) DEFAULT NULL,
  `content` longtext,
  `stars` int DEFAULT NULL,
  `date_time` date DEFAULT NULL,
  PRIMARY KEY (`review_id`),
  UNIQUE KEY `r_id` (`review_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `gwsc_review_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `gwsc_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gwsc_review`
--

LOCK TABLES `gwsc_review` WRITE;
/*!40000 ALTER TABLE `gwsc_review` DISABLE KEYS */;
INSERT INTO `gwsc_review` VALUES ('REVIEW0001','CUS0001','I had the most incredible experience during my stay at the Tropical Aqua Bliss package in the Phi Phi Islands, Thailand. From the moment I arrived, I was captivated by the island\'s natural beauty, with its stunning limestone cliffs and turquoise waters. The beachside campsite was a dream come true, as my Two-Person Tent was just steps away from the soft sandy shores.',5,'2023-07-25');
/*!40000 ALTER TABLE `gwsc_review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-30 11:33:40
